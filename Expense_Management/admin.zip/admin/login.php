<?php
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Your database connection code goes here
    $servername = 'localhost';
    $username_db = 'root'; // Corrected variable name
    $password_db = '';     // Corrected variable name
    $database = "expense_management";
    
    // Create connection
    $conn = new mysqli($servername, $username_db, $password_db, $database); // Corrected variable names

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Prepare and execute SQL statement to retrieve plain text password based on username
    $stmt = $conn->prepare("SELECT password FROM admin WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $row = $result->fetch_assoc();
        $plainTextPasswordFromDatabase = $row['password'];

        // Verify password
        if ($password == $plainTextPasswordFromDatabase) {
            // Password is correct, log in the user
            $_SESSION['username'] = $username;
            header("Location: index.php"); // Redirect to the dashboard page
            exit;
        } else {
            // Password is incorrect
            $error = "Invalid password";
        }
    } else {
        // Username not found
        $error = "Invalid username ";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
</head>
<body>
    <h2>Login</h2>
    <?php if (isset($error)) echo "<p>$error</p>"; ?>
    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
        <label for="username">Username:</label><br>
        <input type="text" id="username" name="username" required><br><br>
        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password" required><br><br>
        <input type="submit" value="Login">
    </form>
</body>
</html>
